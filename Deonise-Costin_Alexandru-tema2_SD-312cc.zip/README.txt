Timp total: 5 ore
Dificultate: 
    primul task: mediu
    al doilea task: mediu
    al treilea task: dificil(nu am reusit sa-l fac)

Task 1

- aflam cine muta primul;
- cream intregul arbore in functie de mutarile posibile;
- mutarile le consideram de la stanga spre dreapta;
- dupa ce am pus mutarea la locul ui, schimbam din X in O
si invers;
- trecem la urmatorul nod;

Task 2
- analog ca la 1 cream arborele de mutari;
- verificam mai intai frunzele;
- plecand de la frunze spre radacina verificam ce tip de nod este(SI/SAU)
si aplica regulile din enunt
- pentru fiecare nivel verificam paritatea astfel incat sa vedem daca este
SI sau SAU
