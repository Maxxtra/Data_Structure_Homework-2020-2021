#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <limits.h>

FILE *f, *g;
// cream structura aferenta
// acel 9 vine de la pozitiile maxime pe care le
// poate avea o tabla de 3x3
typedef struct tree_node
{
    int value;
    int nr_fii;
    char board[3][3];
    char identitate;
    struct tree_node *parent;
    struct tree_node *child[9];
} tree_node_t;

// initializam nodul cu tabla aferenta
tree_node_t *init_node(char board[3][3])
{
    int i, j;
    tree_node_t *new = (tree_node_t *)calloc(1, sizeof(tree_node_t));
    new->nr_fii = 0;
    for (i = 0; i < 9; i++)
        new->child[i] = NULL;
    for (i = 0; i < 3; i++)
        for (j = 0; j < 3; j++)
            new->board[i][j] = board[i][j];
    return new;
}

tree_node_t *init_node3(char value)
{
    tree_node_t *new = (tree_node_t *)calloc(1, sizeof(tree_node_t));
    new->value = value;
    return new;
}

// pentru task-ul 1
// retinem de cate tab-uri avem nevoie
// si afisam clasic cu putc(,)
void print_out(tree_node_t *root, int level)
{
    int k;
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (k = 0; k < level; k++)
            putc('\t', g);
        for (j = 0; j < 2; j++)
        {

            putc(root->board[i][j], g);
            putc(' ', g);
        }
        putc(root->board[i][j], g);
        putc('\n', g);
    }
    putc('\n', g);
}

// pentru task-ul 2
// retinem de cate tab-uri avem nevoie
// si afisam clasic cu putc(,)
void print_out2(tree_node_t *root, int level)
{
    int count;
    int k;
    int i, j;
    for (k = 0; k < level; k++)
        putc('\t', g);
    putc(root->identitate, g);
    putc('\n', g);
    for (count = 0; count < root->nr_fii; count++)
        print_out2(root->child[count], level + 1);
    free(root);
}

// pentru task-ul 1
// verificam starea curenta a jocului
int is_winning(char board[3][3])
{
    int i, j;
    //lines
    for (i = 0; i < 3; i++)
    {
        if (board[i][0] == board[i][1] &&
            board[i][1] == board[i][2] &&
            board[i][2] == 'X')
            return 1;
        if (board[i][0] == board[i][1] &&
            board[i][1] == board[i][2] &&
            board[i][2] == 'O')
            return 1;
    }
    //columns
    for (i = 0; i < 3; i++)
    {
        if (board[0][i] == board[1][i] &&
            board[1][i] == board[2][i] &&
            board[2][i] == 'X')
            return 1;
        if (board[0][i] == board[1][i] &&
            board[1][i] == board[2][i] &&
            board[2][i] == 'O')
            return 1;
    }
    //first diagonal
    if (board[0][0] == board[1][1] &&
        board[1][1] == board[2][2] &&
        board[2][2] == 'X')
        return 1;
    if (board[0][0] == board[1][1] &&
        board[1][1] == board[2][2] &&
        board[2][2] == 'O')
        return 1;
    //second diagonal
    if (board[0][2] == board[1][1] &&
        board[1][1] == board[2][0] &&
        board[2][0] == 'X')
        return 1;
    if (board[0][2] == board[1][1] &&
        board[1][1] == board[2][0] &&
        board[2][0] == 'O')
        return 1;
    //finished, but no winner
    if (board[0][0] != '-' && board[0][1] != '-' && board[0][2] != '-' &&
        board[1][0] != '-' && board[1][1] != '-' && board[1][2] != '-' &&
        board[2][0] != '-' && board[2][1] != '-' && board[2][2] != '-')
        return 1;
    //unfinished
    for (i = 0; i < 3; i++)
        for (j = 0; j < 3; j++)
            if (board[i][j] == '-')
                return 0;
}
// pentru task-ul 2
// vedem daca player-ul curent a castigat
int is_winning2(char board[3][3], char player)
{
    int i, j;
    //lines
    for (i = 0; i < 3; i++)
    {
        if (board[i][0] == board[i][1] &&
            board[i][1] == board[i][2] &&
            board[i][2] == player)
            return 1;
    }
    //columns
    for (i = 0; i < 3; i++)
    {
        if (board[0][i] == board[1][i] &&
            board[1][i] == board[2][i] &&
            board[2][i] == player)
            return 1;
    }
    //first diagonal
    if (board[0][0] == board[1][1] &&
        board[1][1] == board[2][2] &&
        board[2][2] == player)
        return 1;
    //second diagonal
    if (board[0][2] == board[1][1] &&
        board[1][1] == board[2][0] &&
        board[2][0] == player)
        return 1;
    //finished, but no winner
    if (board[0][0] != '-' && board[0][1] != '-' && board[0][2] != '-' &&
        board[1][0] != '-' && board[1][1] != '-' && board[1][2] != '-' &&
        board[2][0] != '-' && board[2][1] != '-' && board[2][2] != '-')
        return 0;
    else //joc e inca in desfasurare; inca mai sunt locuri libere
        return 0;
}

void ex1(tree_node_t *root, char move, int level)
{
    print_out(root, level);      // afisam nodul curent
    if (is_winning(root->board)) // vedem starea curenta
        return;
    if (root == NULL)
        return;
    root->nr_fii = 0;
    int l, c;
    for (l = 0; l < 3; l++)
        for (c = 0; c < 3; c++)
        {
            if (root->board[l][c] == '-')
            {
                tree_node_t *child = init_node(root->board); //cream nod cu tabla aferenta
                child->board[l][c] = move;
                char aux;
                if (move == 'X') //pregatim urmatoarea miscare
                    aux = 'O';
                else
                    aux = 'X';
                root->child[root->nr_fii] = child; //trecem la urmatorul nod
                root->nr_fii++;
                ex1(root->child[root->nr_fii - 1], aux, level + 1); //apelam recursiv
                free(child);
            }
        }
}
// pentru task-ul 2
// cream mai intai nodurile ca la task 1
void ex2_1(tree_node_t *root, char move, int level)
{
    if (is_winning(root->board))
        return;
    if (root == NULL)
        return;
    root->nr_fii = 0;
    int l, c;
    for (l = 0; l < 3; l++)
        for (c = 0; c < 3; c++)
        {
            if (root->board[l][c] == '-')
            {
                tree_node_t *child = init_node(root->board);
                child->board[l][c] = move;
                char aux;
                if (move == 'X')
                    aux = 'O';
                else
                    aux = 'X';
                root->child[root->nr_fii] = child;
                root->nr_fii++;
                ex2_1(root->child[root->nr_fii - 1], aux, level + 1);
            }
        }
}

void ex2(tree_node_t *root, char player, int level)
{
    int i;
    if (root->nr_fii == 0)
        if (is_winning2(root->board, player)) //verificam frunzele
            root->identitate = 'T';
        else
            root->identitate = 'F';
    else
    {
        int count;
        int ok = 0;
        for (count = 0; count < root->nr_fii; count++)
            ex2(root->child[count], player, level + 1); //plecam de la frunze catre radacina
        if (level % 2 == 0)                             //aplicam pentru nodurile SAU
        {
            root->identitate = 'F';
            for (count = 0; count < root->nr_fii; count++)
                if (root->child[count]->identitate == 'T') //daca unul este cu T atunci nodul parinte este T
                {
                    root->identitate = 'T';
                    break;
                }
        }
        if (level % 2 != 0) //aplicam pentru nodurile SI
        {
            root->identitate = 'T';
            for (count = 0; count < root->nr_fii; count++)
                if (root->child[count]->identitate == 'F') //daca doar unul este F, atunci si nodul parinte este F
                    root->identitate = 'F';
        }
    }
}

int main(int argc, char *argv[])
{
    if (strcmp("-c1", argv[1]) == 0)
    {
        f = fopen(argv[2], "r");
        g = fopen(argv[3], "w");
        tree_node_t *root = (tree_node_t *)calloc(1, sizeof(tree_node_t)); //cream radacina
        char c;
        int i, j;
        char to_move;
        to_move = getc(f); //aflam jucatorul
        c = getc(f);
        for (i = 0; i < 3; i++)
            for (j = 0; j < 3; j++)
            {
                c = getc(f);
                root->board[i][j] = c; //cream tabla din radacina
                c = getc(f);
            }
        ex1(root, to_move, 0);
        free(root);
        fclose(f);
        fclose(g);
    }
    if (strcmp("-c2", argv[1]) == 0)
    {
        f = fopen(argv[2], "r");
        g = fopen(argv[3], "w");
        tree_node_t *root = (tree_node_t *)calloc(1, sizeof(tree_node_t)); //cream radacina
        char c;
        int i, j;
        char to_move;
        to_move = getc(f); //aflam player-ul
        c = getc(f);
        for (i = 0; i < 3; i++)
            for (j = 0; j < 3; j++)
            {
                c = getc(f);
                root->board[i][j] = c; //cream tabla din radacina
                c = getc(f);
            }
        ex2_1(root, to_move, 0); //cream arborele
        ex2(root, to_move, 0);
        print_out2(root, 0);
        fclose(f);
        fclose(g);
    }
    if (strcmp("-c3", argv[1]) == 0)
    {
        f = fopen(argv[2], "r");
        g = fopen(argv[3], "w");
        fclose(f);
        fclose(g);
    }
    exit(EXIT_SUCCESS);
}