Dificultate: grea
Timp: suficient de mult, aproape 15 ore

Task 1
- am citit intr-un vector toate numele actorilor, iar in altul am pus
indicii lor;
- am retinut numarul total de actori;
- am facut legaturile in vectorul de indici;
- am facut DFS-recursiv;
- am aflat cea mai mare compomenta conexa;
- am sortat numele in fct de enunt;
- am afisat;

Task2
- analog citirea de la task1;
- am mai citit 2 actori, ca-n enunt;
- am facut un BFS cu o coada;
- am aflat distanta;

Task2
- am implementat pseudocodul din .pdf;
- l-am adaptat la modul meu de citire;
- am aflat puntile;
- am afisat actorii in ordine alfabetica intre care era punte;

Valgrind
- n-am eliberat memoria, deoarece obtinea seg fault;