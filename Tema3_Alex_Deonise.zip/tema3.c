#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <limits.h>

FILE *f, *g;

typedef struct node
{
    int vertex;
    struct node *next;
} node;

typedef struct Graph
{
    int numVertices;
    struct node **adjLists;
} Graph;

// Create a node
node *createNode(int v)
{
    node *newNode = malloc(sizeof(node));
    newNode->vertex = v;
    newNode->next = NULL;
    return newNode;
}

// Create a graph
Graph *createAGraph(int vertices)
{
    Graph *graph = malloc(sizeof(Graph));
    graph->numVertices = vertices;

    graph->adjLists = malloc(vertices * sizeof(node *));

    int i;
    for (i = 0; i < vertices; i++)
        graph->adjLists[i] = NULL;

    return graph;
}

// Add edge
void addEdge(Graph *graph, int s, int d)
{
    // Add edge from s to d
    node *newNode = createNode(d);
    newNode->next = graph->adjLists[s];
    graph->adjLists[s] = newNode;

    // Add edge from d to s
    newNode = createNode(s);
    newNode->next = graph->adjLists[d];
    graph->adjLists[d] = newNode;
}

//----------------------TASK 1-----------------------
void graph_traverse_DFS_recursive(Graph *graph, bool *visited, size_t start_node_id, int *dim, int components[1000], int dimension)
{
    components[*dim] = start_node_id;
    *dim = *dim + 1;
    visited[start_node_id] = 1;
    int i;
    node *aux = graph->adjLists[start_node_id];
    while (aux)
    {
        int id = aux->vertex;
        if (!visited[id])
        {
            graph_traverse_DFS_recursive(graph, visited, id, dim, components, dimension);
        }
        aux = aux->next;
    }
}

int cmp(const void *a, const void *b)
{
    char **s1 = (char **)a;
    char **s2 = (char **)b;
    return strcmp(*s1, *s2);
}

//---------------------------------------------------

//----------------------TASK 2-----------------------

//-----------------------Queue-----------------------
#define SIZE 1000

typedef struct Queue
{
    node *front;
    node *rear;
} Queue;

// Create a queue
Queue *createQueue()
{
    Queue *q = malloc(sizeof(Queue));
    q->front = NULL;
    q->rear = NULL;
    return q;
}

// Check if the queue is empty
int isEmpty(Queue *q)
{
    if (q->rear == NULL)
        return 1;
    else
        return 0;
}

// Adding elements into queue
void enqueue(Queue *q, int value)
{
    node *temp = createNode(value);
    if (q->front == NULL)
    {
        q->front = q->rear = temp;
    }
    else
    {
        q->rear->next = temp;
        q->rear = temp;
    }
}

// Removing elements from queue
int dequeue(Queue *q)
{
    if (isEmpty(q))
        return -1;
    node *temp = q->front;
    q->front = q->front->next;
    int value = temp->vertex;
    free(temp);
    if (q->front == NULL)
        q->rear = NULL;
    return value;
}

// BFS algorithm
void bfs(struct Graph *graph, int startVertex, int endVertex, int *dist)
{
    int visited[6000] = {0};
    int i;
    for (i = 0; i < 6000; i++)
        dist[i] = INT_MAX;
    Queue *q = createQueue();
    visited[startVertex] = 1;
    dist[startVertex] = 0;
    enqueue(q, startVertex);
    while (!isEmpty(q))
    {
        int currentVertex = dequeue(q);
        node *temp = graph->adjLists[currentVertex];
        while (temp)
        {
            int adjVertex = temp->vertex;
            if (visited[adjVertex] == 0)
            {
                dist[adjVertex] = dist[currentVertex] + 1;
                visited[adjVertex] = 1;
                enqueue(q, adjVertex);
            }
            temp = temp->next;
        }
    }
}

//---------------------------------------------------

//----------------------TASK 3-----------------------

int minim(int a, int b)
{
    if (a < b)
        return a;
    return b;
}

void dfsB(Graph *graph, int i, int timp, int *idx, int *low, int *pi, int contor, char *actors_name[], int *valoare, char *string[])
{
    idx[i] = timp;
    low[i] = timp;
    timp++;
    node *j = graph->adjLists[i];
    while (j != NULL)
    {
        if (j->vertex != pi[i])
            if (idx[j->vertex] == -1)
            {
                pi[j->vertex] = i;
                dfsB(graph, j->vertex, timp, idx, low, pi, contor, actors_name, valoare, string);
                low[i] = minim(low[i], low[j->vertex]);
                if (low[j->vertex] > idx[i])
                {
                    int k = 0;
                    string[k] = (char *)calloc(strlen(actors_name[i]) + 1, sizeof(char));
                    strcpy(string[k], actors_name[i]);
                    string[k + 1] = (char *)calloc(strlen(actors_name[j->vertex]) + 1, sizeof(char));
                    strcpy(string[k + 1], actors_name[j->vertex]);
                    qsort(string, 2, sizeof(char *), cmp);
                    *valoare = *valoare + 1;
                }
            }
            else
                low[i] = minim(low[i], idx[j->vertex]);
        j = j->next;
    }
}

void punti(Graph *graph, int all_nodes, char *actors_name[], int *valoare, char *string[])
{
    int timp = 0;
    int idx[1000], low[1000], pi[1000];
    int i;
    for (i = 0; i < all_nodes; i++)
    {
        idx[i] = -1;
        low[i] = INT_MAX;
        pi[i] = 0;
    }
    for (i = 0; i < all_nodes; i++)
        if (idx[i] == -1)
            dfsB(graph, i, timp, idx, low, pi, all_nodes, actors_name, valoare, string);
}

//---------------------------------------------------

int main(int argc, char *argv[])
{
    // ---------------------------------------------
    //
    //                      TASK 1
    //
    //
    // ---------------------------------------------
    if (strcmp("-c1", argv[1]) == 0)
    {
        f = fopen(argv[2], "r");
        g = fopen(argv[3], "w");
        Graph *graph = createAGraph(6000);
        char read[100];
        fgets(read, 100, f);
        int idx_movies = 0;
        idx_movies = atoi(read);
        char **total_actors_movies = (char **)malloc(sizeof(char *) * 6000);
        int contor = 0;
        int i;
        int total_actors_count = 0;
        for (i = 0; i < idx_movies; i++)
        {
            char movie_name[1000];
            fgets(movie_name, 1000, f);
            int idx_actors = 0;
            char read1[100];
            fgets(read1, 100, f);
            idx_actors = atoi(read1);
            int j;
            char actors_movie[1000][100];
            int k, h;
            int ok = 1;
            int idx_current[1000], nr_current = 0;
            for (j = 0; j < idx_actors; j++)
            {
                char actor_name[100];
                fgets(actor_name, 100, f);
                for (k = 0; k < contor; k++)
                    if (strcmp(actor_name, total_actors_movies[k]) == 0)
                    {
                        ok = 0;
                        idx_current[nr_current] = k;
                        nr_current++;
                    }
                if (ok == 1)
                {
                    total_actors_movies[contor] = (char *)calloc(strlen(actor_name) + 1, sizeof(char));
                    strcpy(total_actors_movies[contor], actor_name);
                    idx_current[nr_current] = contor;
                    contor++;
                    nr_current++;
                }
                ok = 1;
                //nr_current++;
            }
            for (j = 0; j < nr_current - 1; j++)
                for (k = j + 1; k < nr_current; k++)
                    addEdge(graph, idx_current[j], idx_current[k]);
        }
        bool visited[6000] = {0};
        int maxim = -1;
        int max_components[6000] = {-1};
        for (i = 0; i < contor; i++)
            if (visited[i] == 0)
            {
                int current = 0;
                int current_components[6000] = {0};
                graph_traverse_DFS_recursive(graph, visited, i, &current, current_components, contor);
                if (current > maxim)
                {
                    maxim = current;
                    int j;
                    for (j = 0; j < maxim; j++)
                        max_components[j] = current_components[j];
                }
            }
        char *actori[6000];
        for (i = 0; i < maxim; i++)
        {
            actori[i] = total_actors_movies[max_components[i]];
        }
        qsort(actori, maxim, sizeof(char *), cmp);
        fprintf(g, "%d\n", maxim);
        for (i = 0; i < maxim; i++)
            fprintf(g, "%s", actori[i]);
        fclose(f);
        fclose(g);
    }
    // ---------------------------------------------
    //
    //                      TASK 2
    //
    //
    // ---------------------------------------------
    if (strcmp("-c2", argv[1]) == 0)
    {
        f = fopen(argv[2], "r");
        g = fopen(argv[3], "w");
        Graph *graph = createAGraph(6000);
        char read[100];
        fgets(read, 100, f);
        int idx_movies = 0;
        idx_movies = atoi(read);
        char **total_actors_movies = (char **)malloc(sizeof(char *) * 6000);
        int contor = 0;
        int i;
        int total_actors_count = 0;
        for (i = 0; i < idx_movies; i++)
        {
            char movie_name[1000];
            fgets(movie_name, 1000, f);
            int idx_actors = 0;
            char read1[100];
            fgets(read1, 100, f);
            idx_actors = atoi(read1);
            int j;
            char actors_movie[1000][100];
            int k, h;
            int ok = 1;
            int idx_current[1000], nr_current = 0;
            for (j = 0; j < idx_actors; j++)
            {
                char actor_name[100];
                fgets(actor_name, 100, f);
                for (k = 0; k < contor; k++)
                    if (strcmp(actor_name, total_actors_movies[k]) == 0)
                    {
                        ok = 0;
                        idx_current[nr_current] = k;
                        nr_current++;
                    }
                if (ok == 1)
                {
                    total_actors_movies[contor] = (char *)calloc(strlen(actor_name) + 1, sizeof(char));
                    strcpy(total_actors_movies[contor], actor_name);
                    idx_current[nr_current] = contor;
                    contor++;
                    nr_current++;
                }
                ok = 1;
            }
            for (j = 0; j < nr_current - 1; j++)
                for (k = j + 1; k < nr_current; k++)
                    addEdge(graph, idx_current[j], idx_current[k]);
        }
        char actor_name[100];
        fgets(actor_name, 100, f);
        // printf("%s", actor_name);
        int id1;
        for (i = 0; i < contor; i++)
            if (strcmp(actor_name, total_actors_movies[i]) == 0)
            {

                id1 = i;
            }
        fgets(actor_name, 100, f);
        ///printf("%s", actor_name);
        int id2;
        for (i = 0; i < contor; i++)
            if (strcmp(actor_name, total_actors_movies[i]) == 0)
                id2 = i;
        int dist[6000];
        //printf("%d %d\n", id1, id2);
        bfs(graph, id1, id2, dist);
        if (dist[id2] != INT_MAX)
            fprintf(g, "%d\n", dist[id2]);
        else
            fprintf(g, "%d\n", -1);
    }
    // // ---------------------------------------------
    // //
    // //                      TASK 3
    // //
    // //
    // // ---------------------------------------------
    if (strcmp("-c3", argv[1]) == 0)
    {
        f = fopen(argv[2], "r");
        g = fopen(argv[3], "w");
        Graph *graph = createAGraph(6000);
        char read[100];
        fgets(read, 100, f);
        int idx_movies = 0;
        idx_movies = atoi(read);
        char **total_actors_movies = (char **)malloc(sizeof(char *) * 6000);
        int contor = 0;
        int i;
        int total_actors_count = 0;
        for (i = 0; i < idx_movies; i++)
        {
            char movie_name[1000];
            fgets(movie_name, 1000, f);
            int idx_actors = 0;
            char read1[100];
            fgets(read1, 100, f);
            idx_actors = atoi(read1);
            int j;
            char actors_movie[1000][100];
            int k, h;
            int ok = 1;
            int idx_current[1000], nr_current = 0;
            for (j = 0; j < idx_actors; j++)
            {
                char actor_name[100];
                fgets(actor_name, 100, f);
                for (k = 0; k < contor; k++)
                    if (strcmp(actor_name, total_actors_movies[k]) == 0)
                    {
                        ok = 0;
                        idx_current[nr_current] = k;
                        nr_current++;
                    }
                if (ok == 1)
                {
                    total_actors_movies[contor] = (char *)calloc(strlen(actor_name) + 1, sizeof(char));
                    strcpy(total_actors_movies[contor], actor_name);
                    idx_current[nr_current] = contor;
                    contor++;
                    nr_current++;
                }
                ok = 1;
            }
            for (j = 0; j < nr_current - 1; j++)
                for (k = j + 1; k < nr_current; k++)
                    addEdge(graph, idx_current[j], idx_current[k]);
        }
        int valoare = 0;
        char *string[6000];
        punti(graph, contor, total_actors_movies, &valoare, string);
        fprintf(g, "%d\n", valoare);
        int k;
        for (k = 0; k < strlen(string[0]); k++)
            if (string[0][k] == '\n' || string[0][k] == 13)
                string[0][k] = '\0';
        fprintf(g, "%s %s", string[0], string[1]);
    }
}