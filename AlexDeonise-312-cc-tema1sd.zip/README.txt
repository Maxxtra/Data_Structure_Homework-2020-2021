Am petrecut mai bine de o saptamana in a rezolva tema. 
Am intampinat dificultati in:
* citirea listei;
* lucrul pe liste;
* implementarea stivelor;
* implementarea unor functii;

Primul test s-a desfasurat in regula, doar ce am citit
caracter cu caracter din .in, le am pus, iar mai apoi am afisat-o.

Al doilea test, a inceput sa fie un prim pas spre adevarata
rezolvare a temei. Aici am intalnit functii:
* gl = am spart string-ul citit, iar mai apoi am dat cursorului
pozitia indicata;
* dl = am verificat daca are ceva dupa litere( numar).

3:
* gc = analog gl;
* b = am sters ultimul caracter;
* d = am pozitionat cursprul si am ster;

4:
* functii deja intalnite *

5:
* ::i = am numaraat de cate ori apare si in functie de numarul
aparitiei, am ales ce sa fac: dau comenzi sau introduc text;
* u = am sters ultima linie;

6: 
* r = de la pozitia finala, am adaugat pe rand fiecare caracter in
lista;

7: 
* functii deja intalnite *
* s ... functii ... q = la s am ales sa printez lista
